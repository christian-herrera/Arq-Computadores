/*
 * DHT11.h
 *
 * Created: 31/5/2023 00:00:49
 *  Author: christian
 */ 


#ifndef DHT11_H_
#define DHT11_H_

#define DHT_TIMEOUT 200  //us


typedef enum {DHT11_OK = 0, DHT11_ERROR_TIMEOUT, DHT11_ERROR_CHECKSUM, DHT11_ERROR_COMM} dht_result;



/************************************************************************/
/*                         FUNCIONES PRIVADAS                           */
/************************************************************************/

// Inicializa el sensor (basicamente los pines)
void DHT_init();


//	Realiza la lectura
//	Parametros:
//	--> [uint16_t*] t:  Puntero donde se almacenara el valor de la Temperatura
//	--> [uint16_t*] h:  Puntero donde se almacenara el valor de la Humedad Relativa
//  Retorno:
//	--> [dht_result] : DHT11_OK, DHT11_ERROR_TIMEOUT, DHT11_ERROR_CHECKSUM, DHT11_ERROR_COMM
dht_result DHT_read(uint16_t * t, uint16_t * h);



#endif /* DHT11_H_ */