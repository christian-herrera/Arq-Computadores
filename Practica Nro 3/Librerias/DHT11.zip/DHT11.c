/*
 * DHT11.c
 *
 * Created: 31/5/2023 00:00:40
 *  Author: christian
 */ 

#define F_CPU 16000000UL

#include <avr/io.h>
#include <util/delay.h>
#include "DHT11.h"


static dht_result DHT_read8bits(uint8_t index);
static uint8_t dht_checkTimeout();

static struct dht_vars_struct{
	uint8_t data[5];
	uint8_t time_cnt;
} dht_vars;



/************************************************************************/
/*                         FUNCIONES PUBLICAS                           */
/************************************************************************/

void DHT_init(){
	//A0 -> INPUT_PULLUP
	DDRC &= ~(1 << PORTC0);		//INPUT
	PORTC |= (1 << PORTC0);		//PULLUP
}



dht_result DHT_read(uint16_t * t, uint16_t * h){

	//HIGH ~ 2ms ~ LOW
	DDRC |= (1 << PORTC0);		//OUTPUT
	PORTC &= ~(1 << PORTC0);	//LOW
	_delay_ms(18);				
	PORTC |= (1 << PORTC0);		//HIGH
	
	//A0 -> INPUT_PULLUP
	DDRC &= ~(1 << PORTC0);		//INPUT
	
	
	//Check si es LOW
	_delay_us(40);
	if((PINC & (1 << PORTC0)) == 1){
		return(DHT11_ERROR_COMM);
	}

	
	//Check  si es HIGH
	_delay_us(80);
	if((PINC & (1 << PORTC0)) == 0){
		return(DHT11_ERROR_COMM);
	}
	
	
	//Leo los 5 bytes
	_delay_us(80);
	uint16_t sm = 0;
	for(uint8_t i = 0; i < 5; i++){
		if(DHT_read8bits(i) == DHT11_ERROR_TIMEOUT){
			return(DHT11_ERROR_TIMEOUT);	
		}
		if(i < 4) sm += dht_vars.data[i];
	}
	
	
	
	//Compruebo el Checksum (la suma de los bits de las 4 lecturas = checksum)
	if(sm == dht_vars.data[4]){
		*h = dht_vars.data[0];
		*t = dht_vars.data[2];
		return(DHT11_OK);
	}
		
	
	return DHT11_ERROR_CHECKSUM;
}



/************************************************************************/
/*                         FUNCIONES PRIVADAS                           */
/************************************************************************/

static dht_result DHT_read8bits(uint8_t index){
	dht_vars.data[index] = 0;
	
	for(uint8_t i = 0; i < 8; i++){
		//Espero al pulso HIGH
		dht_vars.time_cnt = 0;
		while( (PINC & (1 << PORTC0)) == 0){
			_delay_us(1);
			if(dht_checkTimeout()) return(DHT11_ERROR_TIMEOUT);
		}

		_delay_us(30);
		
		//Cuando es HIGH, verifico si es 1 o 0
		if((PINC & (1 << PORTC0)) == 1){
			 dht_vars.data[index] |= (1 << (7 - i));
			 
			 //Espero al pulso LOW
			 dht_vars.time_cnt = 0;
			 while( (PINC & (1 << PORTC0)) == 1){
				 _delay_us(1);
				 if(dht_checkTimeout()) return(DHT11_ERROR_TIMEOUT);
			 }
		}
	}
	return(DHT11_OK);
}




static uint8_t dht_checkTimeout(){
	if(dht_vars.time_cnt++ >= DHT_TIMEOUT){
		return(1);
	}
	return(0);
}