/*
 * USART.c
 *
 * Created: 30/5/2023 21:42:58
 * Author : christian
 */ 

#include "USART.h"
#include <avr/io.h>
#include <stdlib.h>


static char USART_buff[20];


void USART_init(uint32_t freq, uint32_t baud){	
	UBRR0 = (freq/(8 * baud)) - 1;
	
	UCSR0A |= (1 << U2X0);
	UCSR0B = (1<<RXEN0)|(1<<TXEN0);
	UCSR0C = (1<<UCSZ00)|(1<<UCSZ01);
}



void USART_send(uint8_t data){
	while (!(UCSR0A & (1<<UDRE0)));
	UDR0 = data;
}



void USART_sendString(char* data){
	while(*data != 0x00){
		while (!(UCSR0A & (1<<UDRE0)));
		UDR0 = *data;
		data++;
	}
}


void USART_sendInt(uint16_t data){
	itoa(data, USART_buff, 10);
	USART_sendString(USART_buff);
}


void USART_sendByte(uint8_t data){
	itoa(data, USART_buff, 2);
	USART_sendString(USART_buff);
}

