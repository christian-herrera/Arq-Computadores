/*
 * USART.h
 *
 * Created: 30/5/2023 21:42:58
 * Author : christian
 */ 



#ifndef USART_H_
#define USART_H_

#include <avr/io.h>



//	Inicializa la comunicacion Serial
//	Parametros:
//	--> [uint32_t] freq:  Frecuencia del Cristal
//	--> [uint32_t] baud:  Tasa de bits por segundo.
void USART_init(uint32_t freq, uint32_t baud);



//	Envia un byte (Sin interrupciones)
//	Parametros:
//	--> [uint8_t] data: Byte a enviar
void USART_send(uint8_t data);


//	Envia una cadena (Sin Interrupciones)
//	Parametros:
//	--> [char*] data: Bytes en una cadena
void USART_sendString(char * data);


//	Envia un Entero sin signo (Sin Interrupciones)
//	Parametros:
//	--> [uint16_t] data: Entero sin signo
void USART_sendInt(uint16_t data);

//	Envia un Entero byte en formato binario (Sin Interrupciones)
//	Parametros:
//	--> [uint8_t] data: Byte sin signo
void USART_sendByte(uint8_t data);


#endif /* USART_H_ */
